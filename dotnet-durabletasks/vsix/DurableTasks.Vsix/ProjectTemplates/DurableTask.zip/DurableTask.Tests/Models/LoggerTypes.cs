﻿namespace $safeprojectname$
{
    public enum LoggerTypes
    {
        Null,
        List
    }
}
