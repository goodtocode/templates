﻿
namespace $safeprojectname$
{
    public class ObjectA
    {
        public string SomeData { get; set; }
    }

    public class ObjectB
    {
        public string SomeData { get; set; }
    }
}
