﻿namespace $safeprojectname$
{
    public struct StorageTableNames
    {
        public static string DataSourceTable { get; } = "DataSourceTable";
    }
}
