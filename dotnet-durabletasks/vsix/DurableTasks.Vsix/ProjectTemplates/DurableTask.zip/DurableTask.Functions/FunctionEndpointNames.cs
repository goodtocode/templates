﻿namespace $safeprojectname$
{
    public struct FunctionEndpointNames
    {
        public const string Healthcheck = "healthcehck";
        public const string Ping = "ping";
        public const string FanOutClient = "fanout-client";
    }
}

