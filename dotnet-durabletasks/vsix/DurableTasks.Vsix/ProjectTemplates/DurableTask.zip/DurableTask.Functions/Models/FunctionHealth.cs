﻿namespace $safeprojectname$
{
    public class FunctionHealth
    {
        public bool Connected { get; set; }
    }
}
