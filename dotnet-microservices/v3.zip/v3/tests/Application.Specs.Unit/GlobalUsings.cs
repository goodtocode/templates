﻿global using AutoMapper;
global using FluentAssertions;
global using FluentValidation.Results;
global using Microsoft.EntityFrameworkCore;
global using System.Collections.Concurrent;
global using TechTalk.SpecFlow;
