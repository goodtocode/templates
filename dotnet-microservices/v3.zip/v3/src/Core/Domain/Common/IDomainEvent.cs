﻿namespace WeatherForecasts.Core.Domain.Common;

public interface IDomainEvent
{
}