// Global using directives

global using CSharpFunctionalExtensions;