﻿namespace WeatherForecasts.Core.Application.Forecasts.Commands.Remove;

public class RemoveForecastCommandValidator : AbstractValidator<RemoveForecastCommand>
{
    public RemoveForecastCommandValidator()
    {
        RuleFor(x => x.Key).NotEmpty();
    }
}