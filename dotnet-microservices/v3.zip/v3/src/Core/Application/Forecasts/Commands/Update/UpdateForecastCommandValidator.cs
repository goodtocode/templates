﻿namespace WeatherForecasts.Core.Application.Forecasts.Commands.Update;

public class UpdateForecastCommandValidator : AbstractValidator<UpdateForecastCommand>
{
    public UpdateForecastCommandValidator()
    {
        RuleFor(x => x.Key).NotEmpty();
        RuleFor(x => x.Date).NotEmpty();
        RuleFor(x => x.TemperatureF).NotEmpty();
        RuleFor(x => x.Zipcodes).NotNull();
    }
}