﻿namespace WeatherForecasts.Core.Application.Forecasts.Commands.Patch;

public class PatchForecastCommandValidator : AbstractValidator<PatchForecastCommand>
{
    public PatchForecastCommandValidator()
    {
        RuleFor(x => x.Key).NotEmpty();
    }
}