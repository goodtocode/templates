﻿namespace WeatherForecasts.Core.Application.ForecastLists.Queries.GetAll;

public class GetAllForecastsQueryValidator : AbstractValidator<GetAllForecastsQuery>
{
}