﻿namespace WeatherForecasts.Core.Application.ForecastCalculations.Queries.GetCelsiusToFahrenheit;

public class GetCelsiusToFahrenheitCalculationConversionQuery : IRequest<int>
{
    public int CelsiusValue { get; set; }
}

public class
    GetCelsiusToFahrenheitCalculationConversionQueryHandler : IRequestHandler<
        GetCelsiusToFahrenheitCalculationConversionQuery, int>
{
    public async Task<int> Handle(GetCelsiusToFahrenheitCalculationConversionQuery request,
        CancellationToken cancellationToken)
    {
        return request.CelsiusValue! * 9 / 5 + 32;
    }
}