﻿namespace WeatherForecasts.Core.Application.ForecastCalculations.Queries.GetFahrenheitToCelsius;

public class GetFahrenheitToCelsiusCalculationConversionQuery : IRequest<int>
{
    public int FahrenheitValue { get; set; }
}

public class
    GetFahrenheitToCelsiusCalculationConversionQueryHandler : IRequestHandler<
        GetFahrenheitToCelsiusCalculationConversionQuery, int>
{
    public async Task<int> Handle(GetFahrenheitToCelsiusCalculationConversionQuery request,
        CancellationToken cancellationToken)
    {
        return (request.FahrenheitValue - 32) * 5 / 9;
    }
}