﻿global using AutoMapper;
global using Microsoft.EntityFrameworkCore;
global using FluentValidation;
global using MediatR;
global using System.Reflection;