# GoodToCode Microservice Template
Microservice API is built using ASP.NET Core and Entity Framework Core.

## Getting Started
Use these instructions to get the project up and running.

### Prerequisites
You will need the following tools:
* [Visual Studio Code or 2022](https://www.visualstudio.com/downloads/)
* [.NET Core SDK 3.1](https://www.microsoft.com/net/download/dotnet-core/3.1)

### Setup
Follow these steps to get your development environment set up:

  1. Setup your local ASPNETCORE_ENVIRONMENT setting
     ```
	 specifications use the ASPNETCORE_ENVIRONMENT setting 
	 add the ASPNETCORE_ENVIRONMENT entry in your Enviornment Variables > User variables for <<your computer>>

	 to accopmlish this >
	 open Control Panel > System > >Advanced Settings > Environment Variables >System Variables
	 next add new User Variable
		 UserVariables > New
				Variable name:  ASPNETCORE_ENVIRONMENT
				Variable value: Local
	 then Ok (to save)
	 you will need to reboot your machine to see the changes
	 ```

  2. At the root directory, restore required packages by running:
     ```
     dotnet restore
     ```

  3. Launch the backend, within the `MyCo.Microservice.Api' directory
     ```
	 run MyCo.Microservice.Api.csproj project (>Start)
	 ```

  4. Open http://localhost:9023/index.html in your browser to the Swagger API Interface
  
  5. Open http://localhost:9023/specs in your browser to view all CORE Specifications

  6. Run any test scenerios within MyCo.Microservice.Tests 
     ```
	 these specifications scenerios validate the infrastructure and presentation layer
     ```

## Contact
* [@goodtocode](https://www.twitter.com/goodtocode)
* [github.com/goodtocode](https://www.github.com/goodtocode)
* [Repo](https://www.github.com/goodtocode/templates)

## Technologies
* .NET Core 3.1
* ASP.NET Core 3.1

## Additional Technologies References
* AspNetCore.HealthChecks.UI 3.1.2
* Entity Framework Core 3.1
* FluentValidation.AspNetCore 8.0.101
* Microsoft.AspNetCore.App
* Microsoft.AspNetCore.Cors
* Swashbuckle.AspNetCore.SwaggerGen 4.0.1
* Swashbuckle.AspNetCore.SwaggerUI 4.0.1